package capgemini.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExpectedException_Test {
	@Test(expected=ArithmeticException.class)
	//@Test
	public void testDivide(){
		int num1=10;
		int num2=0;
		int expected=2;
		int actual= num1/num2;
		assertEquals(expected,actual);
	}

	@Test(expected=NullPointerException.class)
	//@Test
	public void convertCase(){
		String text=null;	//"uppercase"
		String expected="UPPERCASE";
		String actual=text.toUpperCase();
		assertEquals(expected,actual);
	}
}
