package capgemini.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class AssertEqualTest {
	
	@Test
	public void testAssertEqual(){
		String expected ="JUnit4";
		String actual ="JUnit4";
		assertEquals(expected,actual);
	}

	@Test
	public void testAssertArrayEquals(){
		char[] expected ={'J','U','n','i','t'};
		char[] actual ="JUnit".toCharArray();
		assertEquals(expected,actual);
	}
	
	@Test
	public void testAssertNull(){
		String text = null;
		assertNull("The should NOt be null",text);
	}

	@Test
	public void testAssertArraySame(){
		Object junit4 =new Object();
		Object junit5 =junit4;
		assertSame(junit4,junit5);
	}
	@Test
	public void testAssertArrayNotSame(){
		Object junit4 =new Object();
		Object junit5 =junit4;
		assertNotSame(junit4,junit5);
	}
	
	@Test
	public void testAssertTrue(){
		assertTrue("5 is greater than 4",5>4);
	}
	
	@Test
	public void testAssertFalse(){
		assertFalse("5 is greater than 4",5>4);
	}
	
}
