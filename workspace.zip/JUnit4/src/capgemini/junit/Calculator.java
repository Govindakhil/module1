package capgemini.junit;

public class Calculator {
	public int add(int no1,int no2){
		return no1+no2;
	}
	public int sub(int no1,int no2){
		return no1-no2;
	}
	public int mul(int no1,int no2){
		return no1*no2;
	}
	public int div(int no1,int no2){
		return no1/no2;
	}

}
