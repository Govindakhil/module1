package capgemini.junit;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class IgnoreTimeOut_Test {

	@Ignore("Yet to implement....")
	@Test
	public void testIgnore() {
		System.out.println("testIgnore");
		fail("@ignore mathod will not run by Junit4");
	}

	@Test(timeout = 500)
	public void testTimeOut() {
		System.out.println("@Test(timeout=500) can be used to enforce timeout in JUnit 4");
		while (true) {

		}
	}

}
