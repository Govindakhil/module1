package capgemini.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {
	
	@Test
	public void testAdd(){
		Calculator calc=new Calculator();
		int actual =calc.add(45,5);
		int expected=50;
		assertEquals(expected,actual);
	//fail("testAdd->Not yet implemented");
	}

	@Test
	public void testSub(){
		Calculator calc=new Calculator();
		int actual =calc.sub(30,10);
		int expected=20;
		assertEquals(expected,actual);
		//fail("testSub->Not yet implemented");
	}
	
	@Test
	public void testMul(){
		Calculator calc=new Calculator();
		int actual =calc.mul(30,10);
		int expected=300;
		assertEquals(expected,actual);
		//fail("testMul->Not yet implemented");
	}
	
	@Test
	public void testDiv(){
		Calculator calc=new Calculator();
		int actual =calc.div(20,5);
		int expected=4;
		assertEquals(expected,actual);
		//fail("testDiv->Not yet implemented");
	}
	
	
}
