package capgemini.junit;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;

public class WeekDaysTest {
	
	static String[] weekDay;
	static String[] weekEnd;
	
	List<String> listWeekDay;
	List<String> listWeekEnd;
	
	@BeforeClass
	public static void startup(){
		weekDay = new String[] {"Mon","Tue","Wed","Thus","Fri"};
		weekEnd = new String[] {"Sat","Sun"};
		System.out.println("WeekDayTest->setupdone...");
	}
	
	@AfterClass
	public static void shutdown(){
		weekDay = null;
		weekEnd = null;
	}
	
	
}
