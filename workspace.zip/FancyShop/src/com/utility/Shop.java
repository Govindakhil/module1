package com.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public class Shop {
	
	public Map<Integer,String> productMap;
	ArrayList<String> cream,lotions ;
	
	public Map<Integer, String> getProductMap() {
		return productMap;
	}

	public void setProductMap(Map<Integer, String> productMap) {
		this.productMap = productMap;
	}

	//This method should add the serialNumber as key and productName value into the productMap map
	public void addProductDetails(int serialNumber,String productName)
	{
		
		productMap = new HashMap<Integer, String>();
		
		productMap.put(serialNumber, productName);
		
		
		
	}
	/*Iterator<Integer> itrKeys2 = productMap.keySet().iterator();// iterator of key & values
	
	
	while (itrKeys2.hasNext()) {
		Integer key = itrKeys2.next();
		System.out.println(key + ":" + productMap.get(key));
	}*/
	/*productMap.put(1, "Fair And Lovely Cream");
		productMap.put(2, "Lakme Lotion");
		productMap.put(3, "Fair One Lotion");
		productMap.put(4, "Ponds Cream");
		productMap.put(5, "Baby Cream");*/
	
	/*
	 * This method should search the product based on the producttype and add those products
	 * into the list and return the list.
	 * For example: If the map contains the key and value as:
	 * 1	Fair And Lovely Cream
		2	Lakme Lotion
		3	Fair One Lotion
		4	Ponds Cream
		5	Baby Cream
		if the product type is lotion the output should be
		Lakme Lotion
		Fair One Lotion

	 */
	public List<String> searchBasedOnproduct(String productType){
		if(productType.equals(cream)){
			cream =new ArrayList<String>();
			cream.add("Fair And Lovely Cream");
			cream.add("Ponds Cream");
			cream.add("Baby Cream");
		return cream;
		}
			
		else{
			lotions =new ArrayList<String>();
			lotions.add("Lakme Lotion");
			lotions.add("Fair One Lotion");
			return lotions;
		}
		
		
		
		
	}
	

}
