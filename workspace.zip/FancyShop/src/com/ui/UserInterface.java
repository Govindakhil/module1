package com.ui;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.utility.Shop;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		//Fill the UI code
		System.out.println("Enter the no of Face Creams you want to store:");
		int n=sc.nextInt();
		
		Shop s1=new Shop();
		
		
		for(int i=1;i<=n;i++){
		System.out.println("Enter the key"+i);
		int k=sc.nextInt();
		System.out.println("Enter the value"+i);
		String t=sc.nextLine();
		sc.nextLine();
		s1.addProductDetails(k,t);
		}

		
		/*Iterator<Integer> itrKeys2 = s1.productMap.keySet().iterator(); // iterator of key & values
		
		
		while (itrKeys2.hasNext()) {
			Integer key = itrKeys2.next();
			System.out.println(key + ":" + s1.productMap.get(key));
		}*/
	
		Iterator<String> iterator = (s1.productMap).iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
		
		
	}

}
