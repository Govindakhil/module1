package com.bean;

import java.util.StringTokenizer;

public class Call {
	private int callId;
	private long calledNumber;
	private float duration;
	public int getCallId() {
		return callId;
	}
	
	public long getCalledNumber() {
		return calledNumber;
	}
	
	public float getDuration() {
		return duration;
	}

	public void setCallId(int callId) {
		this.callId = callId;
	}

	public void setCalledNumber(long calledNumber) {
		this.calledNumber = calledNumber;
	}

	public void setDuration(float duration) {
		this.duration = duration;
	}

	public void parseData(String details)
	{
		StringTokenizer st=new StringTokenizer(details);
		while(st.hasMoreTokens()){
			String temp =st.nextToken(":");
			
			setCalledNumber(temp.indexOf(1));
			setDuration(temp.indexOf(2));
			}
	}

}
