package capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Query2_Test {
	public static void main(String[] args) {

		// 1.Download JDBC Driver for Oracle
		// 2.copy to lib folder and add to build path.
		try {
			// 3. load the JDBC driver
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 4.Create Connection
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "INVENTORY1",
					"INVENTORY1");
			connection.setAutoCommit(false);
			
			// 5. create statement for sql query....
						Statement stat = connection.createStatement();
						
						// 6. execute the query
						String SQL = "INSERT INTO DIRECTOR VALUES(? , ?)";

						PreparedStatement pstat = connection.prepareStatement(SQL);
						int dirNumber = 5;
						String dirName = "vishal";

						pstat.setInt(1, dirNumber);
						pstat.setString(2, dirName);
						int rows = pstat.executeUpdate();
						System.out.println(rows + " Inserted...");

						// commit the transaction

						connection.commit();

						// close the database resources

						pstat.close();
						connection.close();

					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}

}
