package capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.*;

public class JDBC_Test {
	public static void main(String[] args) {
	
	//1.Download JDBC Driver for Oracle
	//2.copy to lib folder and add to build path.
	try{
		//3. load the JDBC driver
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		//4.Create Connection
		Connection connection = 
		DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","INVENTORY1","INVENTORY1");
		
		//5. Create Statement for SQL query.....
		Statement stat = connection.createStatement();
		
		//6. Execute the query
		String SQL = "SELECT * FROM CUSTOMER";
		ResultSet rs= stat.executeQuery(SQL);
		
		//7. Process the result
		while(rs.next()){
			System.out.println(rs.getString("first_name"));
		}
		
		//8. close the database resources
		rs.close();
		stat.close();
		connection.close();
		
	}catch(ClassNotFoundException e){
		e.printStackTrace();
	}
	catch(SQLException e){
		e.printStackTrace();
	}
}}



