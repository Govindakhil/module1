package capgemini.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Query_Test {
	public static void main(String[] args) {

		// 1.Download JDBC Driver for Oracle
		// 2.copy to lib folder and add to build path.
		try {
			// 3. load the JDBC driver
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 4.Create Connection
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "INVENTORY1",
					"INVENTORY1");

			// 5. Create Statement for SQL query.....
			Statement stat = connection.createStatement();

			// 6. creating static query
			String SQL = "SELECT * FROM DIRECTOR";
			ResultSet rs = stat.executeQuery(SQL);

 			// Retrieving table structure
			ResultSetMetaData rsmd = rs.getMetaData();
			int colCount = rsmd.getColumnCount();
			for (int index = 1; index <= colCount; index++) {
				String colName = rsmd.getColumnName(index);
				String colType = rsmd.getColumnTypeName(index);
				System.out.println(colName + ":" + colType);
			}

			// 7. Process the result
			while (rs.next()) {
				int dirNumber = rs.getInt("DIRECTOR_NUMBER");
				String dirName = rs.getString("DIRECTOR_NAME");

				System.out.println(dirNumber + ":" + dirName);
			}

			// 8. close the database resources
			rs.close();
			stat.close();
			connection.close();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}