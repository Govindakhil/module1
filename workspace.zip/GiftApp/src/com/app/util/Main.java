package com.app.util;

import java.util.Scanner;

public class Main
{


	public static void main(String args[])
	{


	}

	public static String validateAccessCode(int accessCode)
	{

		return null;
	}
}