package com.app.util;

import java.util.Scanner;
import java.io.*;
public class Main
{

        public static void main(String args[])
        {
          Scanner sc=new Scanner(System.in);
          String str =sc.nextLine();
          System.out.println(generate(str));
            
        }


        public static String generate(String s) 
        {
        	StringBuilder str=new StringBuilder();
            if(s.length()<5){
            	return "Invalid input";
            }
            else{
            	for(int i=0;i<s.length();i=i+2)
            	{
            		str.append(s.charAt(i));
            	}
            	return str.toString().toUpperCase();
            }
        }
}
