import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class EmployeeTest {
	@Test
	public void testAdd(){
		Employee emp=new Employee();
		int actual =calc.add(45,5);
		int expected=50;
		assertEquals(expected,actual);
	//fail("testAdd->Not yet implemented");
	}
}
