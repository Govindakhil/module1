package capgemini.labbook;

import java.util.Scanner;

class AgeException extends Exception{
	public AgeException(String str){
		System.out.println(str);
	}
}
public class Lab5_Ex5_AgeException {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
				System.out.println("Enter ur age :");
		int age=sc.nextInt();
		try{
			if(age<=15)
				throw new AgeException("Invaild age");
			else
				System.out.println("valid age");
		}
		catch(AgeException a){
		System.out.println(a);	
		}
	}

}
