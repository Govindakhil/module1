package capgemini.labbook;
import com.cg.eis.exception.*;
import java.util.Scanner;

class EmployeeException extends Exception{
	public EmployeeException(String str){
		System.out.println(str);
	}
}
public class lab5_Ex6_ {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
				System.out.println("Enter ur Salary :");
		int salary=sc.nextInt();
		try{
			if(salary<=3000) throw new EmployeeException("Exception is");
			else
				System.out.println(" salary is greater than 3000");
		}
		catch(EmployeeException a){
		a.printStackTrace();	
		}
	}


}
