package capgemini.labbook;

import java.util.Scanner;

public class Lab8_Ex7_ApplicationValidation {
	public static boolean valid(String name){
		if(name.length()>=12){
			if(name.endsWith("_job")){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
			
		}
	}
	
	public static void main(String[] args) {
		String name;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Name: ");
		name=sc.next();
		if(valid(name)==true)
		{
			System.out.println("Application is valid");
		}
		else
		{
			System.out.println("Re-enter the name");
		}
		
	}

}
