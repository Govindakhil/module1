package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex3_PrimeNumber {
	public static void main(String[] args) {
		int n,m;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		n=sc.nextInt();
		for(int i=2;i<n;i++)
		{
		 m=0;
		 for(int j=2;j<i;j++)
		 {
			if(i%j==0)
				m=1;
		 }
		 if(m==0)
			 System.out.println(i);
		}
	}

}
