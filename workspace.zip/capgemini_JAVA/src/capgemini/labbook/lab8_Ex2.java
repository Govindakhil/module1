package capgemini.labbook;

import java.util.*;
import java.io.*;

public class lab8_Ex2 {
	public static void main(String[] args) throws IOException {
		File file = new File("c:\\capgemini\\data.out.txt");
		try(FileReader fileReader = new FileReader(file)) {
			LineNumberReader lineNumberReader = new LineNumberReader(fileReader);
			String s = lineNumberReader.readLine();
			while (s!= null) 
			{
				System.out.println(lineNumberReader.getLineNumber() + " " + s);
				s = lineNumberReader.readLine();

			}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
