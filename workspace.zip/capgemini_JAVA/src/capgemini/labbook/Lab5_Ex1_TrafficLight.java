package capgemini.labbook;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

class Radiobutton extends JFrame implements ActionListener{
	private JRadioButton red;
	private JRadioButton orange;
	private JRadioButton green;
	private TextField f;
	Container container;
	
	public Radiobutton()
	{
		super("Radio Buttun Test");
		container =getContentPane();
		container.setLayout(new FlowLayout());
		setVisible(true);
		setSize(350,200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		red=new JRadioButton("red");
		orange=new JRadioButton("orange");
		green=new JRadioButton("green");
		f=new TextField();
		f.setBounds(1,50,70,500);
		/*ButtonGroup group=new ButtonGroup();
		group.add(red);
		group.add(orange);
		group.add(green);*/
		
		red.addActionListener(this);
		orange.addActionListener(this);
		green.addActionListener(this);
		container.add(red);
		container.add(orange);
		container.add(green);
		container.add(f);	
		
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==red){
			f.setText("stop");
			container.setBackground(Color.red);
		}
		if(e.getSource()==orange){
			f.setText("ready");
			f.setBackground(Color.yellow);
		}
		if(e.getSource()==green){
			f.setText("go");
			f.setBackground(Color.green);
		}
	}

}

public class Lab5_Ex1_TrafficLight {
	public static void main(String[] args) {
		Radiobutton r1=new Radiobutton();
	}

}
