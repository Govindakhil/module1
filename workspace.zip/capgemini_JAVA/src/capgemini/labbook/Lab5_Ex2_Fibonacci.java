package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex2_Fibonacci {
	
			public static int fib(int n){
			if(n<=1)
			{
				return n;
			}
			else
			{
				return fib(n-1)+fib(n-2);
			}
			}
	
	public static void main(String[] args) {
		int a=1,b=1,c=0,i;
	Scanner sc=new Scanner(System.in);
	int n = sc.nextInt();
	System.out.println(fib(n));
	for(i=1;i<=n;i++)
	{
		c=a+b;
		a=b;
		b=c;
	}
	System.out.print(c);
	}
	

}
