package capgemini.labbook;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Lab9_Ex2_countCharacter {
	public static void main(String[] args) {
		String str;
		Scanner sc = new Scanner(System.in);
		str = sc.nextLine();
		char[] c = str.toCharArray();
		Arrays.sort(c);
		HashMap<Character, Integer> hash = new HashMap<Character, Integer>();
		int count = 1;
		for (int i = 0; i < c.length-1; i++) {
			if (c[i] != c[i + 1]) {
				hash.put(c[i], count);
				count = 1;
			} 
			else {
				count++;
			}
			hash.put(c[c.length - 1], count);
		}
		Iterator<Character> iterator = hash.keySet().iterator();
		while (iterator.hasNext()) {
			char d;
			d = iterator.next();
			System.out.println(d + "=" + hash.get(d));
		}
	}

}
