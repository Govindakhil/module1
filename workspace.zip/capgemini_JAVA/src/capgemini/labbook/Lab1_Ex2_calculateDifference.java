package capgemini.labbook;

import java.util.Scanner;

public class Lab1_Ex2_calculateDifference
{
	private static Scanner sc;
	public static int calculateDifference(int n)
	{
		int i,sum1=0,sum2=0,t=0;
		for(i=1;i<=n;i++)
		{
			
			sum1=sum1+i*i;
			sum2=sum2+i;
			
		}
		t=sum2*sum2;
		return sum1-t;
		 
		

	}
	public static void main(String[] args)
	{
		int n;
		sc = new Scanner(System.in);
		n=sc.nextInt();
		int result=calculateDifference(n);
		System.out.println("sum= "+result);
	}
}
		