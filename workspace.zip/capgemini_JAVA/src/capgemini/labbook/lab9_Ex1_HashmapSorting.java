package capgemini.labbook;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class lab9_Ex1_HashmapSorting {
	public static void main(String[] args) {
		HashMap<Integer, String> hm=new HashMap<Integer, String>();
		hm.put(10, "Harshith");
		hm.put(5, "SaiPavan");
		hm.put(6, "Chandu");
		hm.put(3, "Surendra");
		List<String> list=getValues(hm);
		System.out.println(list);
		
	}
	private static List<String> getValues(HashMap<Integer, String>hm){
		List<String> l1 =new ArrayList<String>();
		Iterator<String> iterator = hm.values().iterator();
		while(iterator.hasNext()){
			l1.add(iterator.next());
		}
		Collections.sort(l1);
		return l1;
		
	}
	

}
