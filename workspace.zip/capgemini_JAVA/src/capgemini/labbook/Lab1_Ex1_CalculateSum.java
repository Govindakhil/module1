package capgemini.labbook;

import java.util.Scanner;

public class Lab1_Ex1_CalculateSum 
{

	public static int calculateSum(int n)
	{
		int i,sum=0;
		for(i=0;i<n;i++)
		{
			if(i%3==0||i%5==0)
			{
					sum=sum+i;
			}
		}
		return sum;
	}
	public static void main(String[] args)
	{
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int result=calculateSum(n);
		System.out.println("sum= "+result);
		
	}
		
	}
