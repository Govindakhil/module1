package capgemini.labbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

class CopyDataThread extends Thread{
	@Override
	public void run() {
	}
	
	public CopyDataThread(FileInputStream fileInputStream,FileOutputStream fileOutputStream) throws IOException, InterruptedException {
		int count=0;
		int t;
		try{
		t=fileInputStream.read();
		while(t!= -1)
		{
			count++;
			fileOutputStream.write((char) t);
			if(count==10)
			{
				System.out.println("10 characters are copied");
				Thread.sleep(5000);
				count=0;
			}
			t=fileInputStream.read();
		}
	
		}catch(IOException e){
			e.printStackTrace();
		}catch(InterruptedException e){
			e.printStackTrace();
	}
}
}
public class Lab10_Ex1_FileProgram {
	
	public static void main(String[] args) throws InterruptedException {
		File file=new File("c:\\capgemini\\source.txt");
		try{
			FileInputStream fileInputStream=new FileInputStream(file);
			FileOutputStream fileOutputStream=new FileOutputStream("c:\\capgemini\\target.txt");
			CopyDataThread copyDataThread=new CopyDataThread(fileInputStream, fileOutputStream);
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
		Thread t1=new Thread();
		t1.start();
	}

}
