package capgemini.labbook.Lab14.src.com.cg.eis.serviceLab14.src.com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeServiceInterface {
	public Employee insuranceScheme(Employee e);
	public String designation(Employee e);
}
