package capgemini.labbook;

import java.util.Scanner;

public class Lab4_SumOfCubes {
	public static double sumOfCubes(int n){
		int i,temp;
		double sum=0;
		while(n>0)
		{
		temp=n%10;
		sum=sum+Math.pow(temp, 3);
		n=n/10;
		}
		return sum;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("Sum of cubes of number is "+sumOfCubes(n));
	}

}
