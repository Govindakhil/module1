package capgemini.labbook;

import java.io.File;
import java.util.Scanner;

public class Lab8_Ex4_File {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String path = sc.next();
		File file = new File(path);
		System.out.println("Does the file exists " + file.exists());
		System.out.println("Does the file is readable " + file.canRead());
		System.out.println("Does the file is Writable " + file.canWrite());
		System.out.println("File length " + file.length()*2);
		System.out.println("File length " +(( file.length()*Character.SIZE)/8));
		String s = null;
		int index = path.lastIndexOf(".");
		if (index >= 0) {
			s = path.substring(index + 1);
		}
		System.out.println("file type: " + s);
		int length = (int) file.length();
		System.out.println(length);
		
	}

}
