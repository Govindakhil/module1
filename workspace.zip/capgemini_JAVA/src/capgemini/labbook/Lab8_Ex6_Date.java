package capgemini.labbook;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Lab8_Ex6_Date {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		LocalDate pdate= LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt());
		LocalDate now= LocalDate.now();
		
		Period diff =Period.between(now,pdate);
		System.out.println("difference in period: "+diff.getYears()+"\t"+diff.getMonths()+"\t"+diff.getDays());
		
	}

}
