package capgemini.labbook;

import java.util.Scanner;

public class Lab3_Ex1 {
	public static int getSecondSmallest(int[]a,int n){
		int temp;
		for(int i=0;i<n;i++)
		{
			for(int j=i;j<n;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a[1];
	}
	public static void main(String[] args) {
		int b,j;
		Scanner s=new Scanner(System.in);
		b=s.nextInt();
		int a[]=new int [b];
		
		for(j=0;j<b;j++){
			
		a[j]=s.nextInt();
	}
	System.out.println("secondsmallest number:"+getSecondSmallest(a,b));
	}

}
