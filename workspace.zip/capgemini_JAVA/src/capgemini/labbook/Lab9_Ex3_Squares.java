package capgemini.labbook;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Lab9_Ex3_Squares {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] a = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		Map<Integer, Integer> map = getSquares(a);
		Iterator<Integer> iterator = map.keySet().iterator();
		while (iterator.hasNext()) {
			int square = iterator.next();
			System.out.println(square + "=" + map.get(square));

		}

	}

	private static Map getSquares(int[] a) {
		HashMap<Integer, Integer> hash = new HashMap<Integer, Integer>();
		int s = 0;
		for (int i = 0; i < a.length; i++) {
			s = a[i] * a[i];
			hash.put(a[i], s);
		}
		return hash;
	}

}
