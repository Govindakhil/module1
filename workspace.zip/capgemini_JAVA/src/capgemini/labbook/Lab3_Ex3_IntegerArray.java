package capgemini.labbook;
import java.util.Arrays;
import java.util.Scanner;
public class Lab3_Ex3_IntegerArray {
	public static void main(String[] args) {
	int n,i;	
	Scanner sc=new Scanner(System.in);
	n=sc.nextInt();
	int arr[] = new int[n];
	for(i=0;i<n;i++){
		arr[i]=sc.nextInt();
	}
	int b[]=getsorted(arr);
	for(i=0;i<b.length;i++){
		int v=b[i];
		System.out.print(v);
	}
	}
	public static int[]getsorted(int[] arr){
		int i;
		for(i=0;i<arr.length;i++){
			String s;
			StringBuilder str=new StringBuilder();
			s=str.append(arr[i]).reverse().toString();
			arr[i]=Integer.parseInt(s);
			}
			Arrays.sort(arr);
			return arr;
			
	}
	}
		