package capgemini.labbook;

import java.util.Scanner;

public class Lab8_Ex5_PositiveString {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String t=s.toLowerCase();
		int flag=1;
		for(int i=0;i<t.length()-1;i++){
			if(t.charAt(i)<=t.charAt(i+1))
			{
				flag=1;
			}
			else{
				flag=0;
				break;
			}
		}
		if(flag==1){
			System.out.println("positive String");
		}
		else{
			System.out.println("not positive String");
		}
	}

}
