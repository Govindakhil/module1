package capgemini.interfaces;

public interface IStack_Test {

}
