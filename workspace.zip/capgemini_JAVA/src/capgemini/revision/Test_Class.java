package capgemini.revision;

class Product {

	// fields
	private int productId;
	private String name;
	private float cost;

	// Default constructor
	public Product() {
		setProductId(0);
		setName(null);
		setCost(0);
	}

	// Parameterized constructor
	public Product(int ProductId, String Name, float Cost) {
		this.productId = ProductId;
		this.name = Name;
		this.cost = Cost;

	}

	// Getter and Setter Methods
	public int getProductId() {
		return productId;
	}

	public void setProductId(int ProductId) {
		this.productId = ProductId;
	}

	public String getName() {
		return name;
	}

	public void setName(String Name) {
		this.name = Name;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float Cost) {
		this.cost = Cost;
	}

	// Generating to toString
	@Override
	public String toString() {
		return "Name= " + name + "\tProductId= " + productId + "\tCost= " + cost;
	}

	// Generating Equals Method
	@Override
	public boolean equals(Object obj) {

		//type casting
		Product otherProduct =(Product) obj;
		//compare values...
		if(productId==otherProduct.getProductId()
				&&name.equals(otherProduct.getName())
				&& cost==otherProduct.getCost())
		return true;
		else
			return false;
		
	}

}

public class Test_Class {
	public static void main(String[] args) {

		Product p1, p2;

		p1 = new Product();
		p1.setProductId(1);
		p1.setName("Dell-Laptop");
		p1.setCost(55555f);

		// print p1 values
		System.out.println(p1);
		System.out.println("ProductID: " + p1.getProductId());
		System.out.println("ProductName: " + p1.getName());
		System.out.println("ProductCost: " + p1.getCost());

		p2 = new Product(2, "Asus-Laptop", 60000f);
		System.out.println(p2);
		
		if(p1.equals(p2))
				System.out.println("p1 equals p2");
		else
			System.out.println("p1 not equals p2");
		
		//object arrays ....or products
		
		Product[] products=new Product[3];
		products[0]=new Product(1,"Asus",55555f);
		products[1]=new Product(2,"Dell",60000f);
		products[2]=new Product(3,"Acer",50000f);
		float totalCost=0;
		for(int index=0;index<products.length;index++){
			totalCost+=products[index].getCost();
		}
		System.out.println("Total Cost:"+totalCost);
	
	}

}
