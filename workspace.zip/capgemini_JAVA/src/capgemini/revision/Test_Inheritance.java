package capgemini.revision;

abstract class Document{
	public abstract void open();
	public abstract void read();
	public abstract void write();
	public abstract void close();
	
	String text;
	
	public Document(){
		System.out.println("Document->def.....");
		text="Documents....";
		System.out.println(text);
	}
	public Document(String text){
		System.out.println("Document->param.....");
		this.text=text;
		System.out.println(text);
	}
	
	@Override
	public String toString() {
		return "Document->text:"+text;
	}
	
	
	
	
	
}
 class Word extends Document{
	 
	 public Word(){
		 super("Word Documents...");
		 System.out.println("Word->def.....");
		
	 }
	 
	 public Word(String text){
		 super(text);
		 System.out.println("Word->param.....");
	 }
	 

	@Override
	public void open() {
		System.out.println("Word is Opened");
	}

	@Override
	public void read() {
		System.out.println("Reading the Word");
		
	}

	@Override
	public void write() {
		System.out.println("Writing the Word");	
	}

	@Override
	public void close() {
		System.out.println("Word is closed");	
	}
	

	@Override
	public String toString() {
		return super.toString()+ " Word:"+text;
	}
	
}
class Excel extends Document{
	
	public Excel(){
		 super("Excel Documents...");
		 System.out.println("Excel->def.....");
	 }
	 
	 public Excel(String text){
		 super(text);
		 System.out.println("Excel->param.....");
	 }

	@Override
	public void open() {
		System.out.println("Excel is Opened");			
	}

	@Override
	public void read() {
		System.out.println("Reading the Excel");			
	}

	@Override
	public void write() {
		System.out.println("Writing the Excel");	
	}

	@Override
	public void close() {
		System.out.println("Excel is closed");			
	}
	
	@Override
	public String toString() {
		return super.toString()+" Excel:"+text;
	}
	
}

class PowerPoint extends Document{

	public PowerPoint(){
		 super("PowerPoint Documents...");
		 System.out.println("PowerPoint->def.....");
	 }
	 
	 public PowerPoint(String text){
		 super(text);
		 System.out.println("PowerPoint->def.....");
	 }

	@Override
	public void open() {
		System.out.println("PowerPoint is Opened");			
	}

	@Override
	public void read() {
		System.out.println("Reading the PowerPoint");	
	}

	@Override
	public void write() {
		System.out.println("Writing the PowerPoint");		
	}

	@Override
	public void close() {
		System.out.println("PowerPoint is closed");
	}
	
	@Override
	public String toString() {
		return super.toString()+" PowerPoint:"+text;
	}
	
	
}



public class Test_Inheritance {
	
	public static void main(String[] args) {
		
		Word word = new Word();
		word.open();
		word.read();
		word.write();
		word.close();
		System.out.println(word);
		
		Excel excel = new Excel("Excel is pending");
		excel.open();
		excel.read();
		excel.write();
		excel.close();
		System.out.println(excel);
		
		PowerPoint powerPoint = new PowerPoint();
		powerPoint.open();
		powerPoint.read();
		powerPoint.write();
		powerPoint.close();
		System.out.println(powerPoint);
		
	}
	
	

}
