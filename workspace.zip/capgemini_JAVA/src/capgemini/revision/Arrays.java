package capgemini.revision;

public class Arrays {
	public static void main(String[] args) {
		//int arrays definition/declaration
		int[] nums;
		
		//memory allocation,all 0 values
		nums=new int[3];
		
		//assign values to elements
		String[] names=new String[3];
		names[0]= "Amar";
		names[1]="Vikram";
		names[2]="Nikita";
		
		String[] names2=new String[] {"Amar","Vikram","Nikita"};
		
		System.out.println(Arrays.toString(nums));
		System.out.println(Arrays.toString(names));
		
	}

}
