package capgemini.revision;

interface Printer{
	public void print(Document doc);
	
}
class HPPrinter implements Printer{

	private static int COUNT=0;
	@Override
	public void print(Document doc) {
		HPPrinter.COUNT+=1;
		System.out.println(doc);
	}
	public int getCOUNT(){
		return COUNT;
	}
	
}

public class Test_Interface {
	public static void main(String[] args) {
		Word word=new Word("MS Word");
		Excel excel=new Excel("MS Excel");
		Printer printer=new HPPrinter();
		printer.print(word);
		printer.print(excel);
		
		
	}

}
