package com.cg.eis.exception;

public class EmployeeException extends Exception
{
public EmployeeException(String message) {
	super(message);
}
@Override
public String getMessage(){
	return super.getMessage()+"salary is lessthan 3000";
}
}
