package com.capgemini.banking.test;

public class Account {
	static int ACCOUNT_NUMBER_SEQUENCE = 100;
	private int accountNo;
	private String accountName;
	private double openingBalance;
	private double currentBalance;

	public Account(String accountName, double openingbalance) {
		super();
		ACCOUNT_NUMBER_SEQUENCE++;
		setAccountNo(ACCOUNT_NUMBER_SEQUENCE);
		setAccountName(accountName);
		setOpeningBalance(openingbalance);
		setCurrentBalance(openingbalance);
	}

	public static int getACCOUNT_NUMBER_SEQUENCE() {
		return ACCOUNT_NUMBER_SEQUENCE;
	}

	public static void setACCOUNT_NUMBER_SEQUENCE(int aCCOUNT_NUMBER_SEQUENCE) {
		ACCOUNT_NUMBER_SEQUENCE = aCCOUNT_NUMBER_SEQUENCE;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountName=" + accountName + ", openingBalance=" + openingBalance
				+ ", currentBalance=" + currentBalance + "]";
	}

}
