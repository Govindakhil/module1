package Lab2_Library;

class Cd extends MediaItem {
	private String artist,genre;

	@Override
	public int getRuntime() {
		return runtime;
	}

	public Cd(String artist, String genre) {
		super();
		setArtist(artist);
		setGenre(genre);
	}
	
	public Cd(){
		super();
		this.artist=null;
		this.genre=null;
	}
	
	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public void setRuntime(int runtime) {
		this.runtime=runtime;
				
	}


	@Override
	public int getUniqueIdentificationnumber() {
		return uniqueIdentificationnumber;
	}

	@Override
	public void setuniqueIdentificationnumber(int uniqueIdentificationnumber) {
		this.uniqueIdentificationnumber=uniqueIdentificationnumber;
	}

	@Override
	public String getTitle() {
		return Title;
	}

	@Override
	public void setTitle(String title) {
		this.Title=title;		
	}

	@Override
	public int getNumber_of_Copies() {
		return number_of_Copies;
	}

	@Override
	public void setNumber_of_Copies(int number_of_Copies) {
		this.number_of_Copies=number_of_Copies;
	}

	@Override
	public String toString() {
		return "Cd [artist=" + artist + ", genre=" + genre + ", runtime=" + runtime + ", uniqueIdentificationnumber="
				+ uniqueIdentificationnumber + ", Title=" + Title + ", number_of_Copies=" + number_of_Copies + "]";
	}

	
	
	

}
