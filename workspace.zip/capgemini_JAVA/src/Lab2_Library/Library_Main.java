package Lab2_Library;

import java.util.Scanner;

public class Library_Main {
	public static void main(String[] args) {
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		switch(n){
		
		case 1:
			Video v=new Video();
			v.setDirector("Vikram");
			v.setGenre("pop");
			v.setNumber_of_Copies(90);
			v.setRuntime(5);
			v.setTitle("Indra");
			v.setuniqueIdentificationnumber(101);
			v.setYearReleased(2005);
			System.out.println(v.toString());
			break;
		case 2:	
			Cd c=new Cd();
			c.setArtist("Akhil");
			c.setGenre("pop");
			c.setNumber_of_Copies(80);
			c.setRuntime(5);
			c.setTitle("Cobra");
			c.setuniqueIdentificationnumber(102);
			System.out.println(c.toString());
			break;
		case 3:	
			Book b=new Book();
			b.setNumber_of_Copies(90);
			b.setTitle("Half_Girlfriend");
			b.setAuthor("Chetan Bhagat");
			b.setuniqueIdentificationnumber(103);
			System.out.println(b.toString());
			break;
		case 4:	
			JournalPaper j=new JournalPaper();
			j.setAuthor("Indra");
			j.setTitle("RockStudy");
			j.setYearpublised(1997);
			j.setuniqueIdentificationnumber(104);
			System.out.println(j.toString());
			break;
		}
	}

}
