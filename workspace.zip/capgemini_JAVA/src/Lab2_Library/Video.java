package Lab2_Library;

class Video extends MediaItem {

	private int runtime, yearReleased;
	private String director, genre;

	@Override
	public int getRuntime() {
		return runtime;
	}

	@Override
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}

	public Video() {
		this.runtime = 0;
		this.yearReleased = 0;
		this.director = null;
		this.genre = null;
	}

	public Video(int yearReleased, String director, String genre) {
		super();
		setYearReleased(yearReleased);
		setDirector(director);
		setGenre(genre);
	}

	public int getYearReleased() {
		return yearReleased;
	}

	public void setYearReleased(int yearReleased) {
		this.yearReleased = yearReleased;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public int getUniqueIdentificationnumber() {
		return 0;
	}

	@Override
	public void setuniqueIdentificationnumber(int uniqueIdentificationnumber) {
		this.uniqueIdentificationnumber = uniqueIdentificationnumber;
	}

	@Override
	public String getTitle() {
		return Title;
	}

	@Override
	public void setTitle(String title) {
		this.Title = title;
	}

	@Override
	public int getNumber_of_Copies() {
		return number_of_Copies;
	}

	@Override
	public void setNumber_of_Copies(int number_of_Copies) {
		this.number_of_Copies = number_of_Copies;
	}

	@Override
	public String toString() {
		return "Video [runtime=" + runtime + ", yearReleased=" + yearReleased + ", director=" + director + ", genre="
				+ genre + ", uniqueIdentificationnumber=" + uniqueIdentificationnumber + ", Title=" + Title
				+ ", number_of_Copies=" + number_of_Copies + "]";
	}

	
}
