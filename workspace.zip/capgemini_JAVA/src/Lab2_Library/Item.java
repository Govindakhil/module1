package Lab2_Library;

abstract class Item {
	 protected int uniqueIdentificationnumber;
	 protected String Title;
	 protected int number_of_Copies;
	public abstract int getUniqueIdentificationnumber();
	public abstract void setuniqueIdentificationnumber(int uniqueIdentificationnumber);
	public abstract String getTitle();
	public abstract void setTitle(String title);
	public abstract int getNumber_of_Copies();
	public abstract void setNumber_of_Copies(int number_of_Copies);
	
}
