package capgemini_JAVA;
//Author: Govind akhil
//Date: 24/07/2019
//Purpose:To print Datatypes...
public class Datatype 
{
	public static void main(String[] args) 
	{
		//declare data type
		int empid;
		String name;
		char gender;
		boolean IsWorking;
		float salary;
		
		//initialisation
		empid=101;
		name=null;
		gender='M';
		IsWorking=true;
		salary=25555.50f;
		System.out.println("Empid:"+empid);
		System.out.println("Name:"+name);
		System.out.println("Gender:"+gender);
		System.out.println("Working:"+IsWorking);
		System.out.println("Salary:"+salary);
}
}
