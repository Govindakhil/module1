package capgemini_JAVA;

public class WrapperRange {
	public static void main(String[] args) {
		System.out.println("Byte: Min & Max value :" + Byte.MIN_VALUE+" : "+Byte.MAX_VALUE);
		System.out.println("Short: Min & Max value :" + Short.MIN_VALUE+" : "+Short.MAX_VALUE);
		System.out.println("Integer: Min & Max value :" + Integer.MIN_VALUE+" : "+Integer.MAX_VALUE);
		System.out.println("Long: Min & Max value :" + Long.MIN_VALUE+" : "+Long.MAX_VALUE);
		System.out.println("Float: Min & Max value :" + Float.MIN_VALUE+" : "+Float.MAX_VALUE);
		System.out.println("Double: Min & Max value :" + Double.MIN_VALUE+" : "+Double.MAX_VALUE);
		System.out.println("Boolean: True or Flase value :" + Boolean.TRUE+" : "+Boolean.FALSE);
		System.out.println("Character: Min & Max value :" + Character.MIN_VALUE+" : "+Character.MAX_VALUE);
	}

}
