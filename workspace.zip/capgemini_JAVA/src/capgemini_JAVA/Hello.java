package capgemini_JAVA;

//Author: Govind akhil
//Date: 24/07/2019
//Purpose:To print Hello..
public class Hello{
	public static void main(String args[]){
		System.out.println("Hello..");
	}
}