package com.capgemini.dao.services;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.dao.bean.Account;
import com.capgemini.dao.bean.Transaction;
import com.capgemini.dao.exceptions.*;
import com.capgemini.jdbc.DaoImpl;

public class BankingServiceImpl implements BankingService {
	static Scanner sc = new Scanner(System.in);
	DaoImpl daoImpl = new DaoImpl();

	@Override
	public void createAccount(Account account) {

		daoImpl.insert(account);

	}

	@Override
	public void deposit(double amount, Integer accno) throws AccountNotFoundException {
		double curbal = 0;
		String s = "select accno from Account where accno=" + accno;
		Integer accNo1 = Integer.parseInt(daoImpl.query(s));
		// System.out.println(accNo1);
		if (accNo1.equals(accno)) {
			String s1 = "select initialbalance from Account where accno=" + accno;
			double initial = Integer.parseInt(daoImpl.query(s1));
			curbal += initial + amount;
			daoImpl.update(curbal, accno);
			System.out.println("Deposit done successfully");
			Transaction transaction = new Transaction("CR", "Deposited", amount);

			java.sql.Date date = getCurrentDate();
			daoImpl.addTrans(transaction, accno, date);

		} else {

			try {
				throw new AccountNotFoundException(accno, "Account not found");
			} catch (AccountNotFoundException e) {

			}

		}

	}

	public java.sql.Date getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}

	@Override
	public void withDraw(double amount, Integer accno) throws AccountNotFoundException, InsufficientBalanceException {
		double curbal = 0;
		String s = "Select AccountNo from Account where AccountNo=" + accno;
		Integer accNo1 = Integer.parseInt(daoImpl.query(s));
		if (accNo1.equals(accno)) {

			String s1 = "Select initialbalance from Account where AccountNo=" + accno;
			double initial = Integer.parseInt(daoImpl.query(s1));

			if (initial >= amount) {
				curbal += initial - amount;
				daoImpl.update(curbal, accno);

				System.out.println("withdrawl is done");
				Transaction transaction = new Transaction("DR", "Debited", amount);

				java.sql.Date date = getCurrentDate();
				daoImpl.addTrans(transaction, accno, date);

			} else {

				throw new InsufficientBalanceException(accno, " has Insufficient balance");
			}
		} else {

			throw new AccountNotFoundException(accno, "account not found");
		}
	}

	@Override
	public void fundTransfer(Integer accno1, Integer accno2)
			throws InsufficientBalanceException, AccountMismatchException {
		double senderInitial = 0, receiveamt = 0, amount = 0;
		if (accno1.equals(accno2))
			throw new AccountMismatchException(accno1, accno2, "are same");
		else {
			String s = "Select initialbalance from Account where AccountNo=" + accno1;
			double initial = Integer.parseInt(daoImpl.query(s));
			String s2 = "Select initialbalance from Account where AccountNo=" + accno2;
			double initial2 = Integer.parseInt(daoImpl.query(s2));
			System.out.println("Enter amount to be transfered");
			amount = sc.nextDouble();
			if (amount > initial) {
				throw new InsufficientBalanceException(accno1, "Amount greater than bankbalance");
			} else {
				receiveamt = initial2 + amount;
				senderInitial = initial - amount;

				System.out.println("funds transfered");

				daoImpl.update(senderInitial, accno1);
				daoImpl.update(receiveamt, accno2);
				Transaction transaction1 = new Transaction("DR", "Deposited", amount);

				java.sql.Date date = getCurrentDate();
				daoImpl.addTrans(transaction1, accno1, date);
				Transaction transaction = new Transaction("CR", "Deposited", amount);

				java.sql.Date date2 = getCurrentDate();
				daoImpl.addTrans(transaction, accno2, date2);
			}
		}
	}

}
