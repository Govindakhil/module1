package com.capgemini.dao.exceptions;

public class InvalidQueryException {

}
