package com.capgemini.jdbc;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.capgemini.dao.bean.Account;
import com.capgemini.dao.bean.Transaction;
import com.capgemini.dao.exceptions.AccountNotFoundException;

public interface Dao {
	public void insert(Account account);

	public void update(double balance, Integer accno);

	public void delete(Integer accno) throws AccountNotFoundException;

	// public void showBalance1(Integer accno) throws AccountNotFoundException;

	public void addTrans(Transaction transaction, Integer accno, Date date);

	public void query();

}
